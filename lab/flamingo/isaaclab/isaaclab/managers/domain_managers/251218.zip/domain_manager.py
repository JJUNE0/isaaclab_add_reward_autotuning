from __future__ import annotations
import math
import torch
from torch.distributions import StudentT
from scipy import stats  # [추가] Scipy 통계 모듈 사용

from collections.abc import Sequence
from copy import deepcopy
from typing import TYPE_CHECKING, Any
import inspect # [필수 추가]

from isaaclab.envs import ManagerBasedRLEnv
from isaaclab.managers.event_manager import EventManager, EventTermCfg 
from isaaclab.managers import SceneEntityCfg

from .domain_manager_term_cfg import DomainManagerTermCfg

if TYPE_CHECKING:
    from isaaclab.assets import Articulation
    
    
from collections import deque

class DomainManager(EventManager):

    cfg: DomainManagerTermCfg

    def __init__(self, cfg: DomainManagerTermCfg, env: ManagerBasedRLEnv):
        super().__init__(cfg, env)
        
        # 0.0(Easy: No Random) -> 1.0(Hard: Full Random)
        self.difficulty_level = cfg.init_difficulty_level
        self.initial_level = cfg.initial_level
    
        self.threshold = cfg.curriculum_threshold
        self.step_size = cfg.curriculum_stage_gain
        self.threshold_increment = cfg.curriculum_threshold_increment

        self.max_params = {}
        self._capture_max_params()
        
        
        # -------------------------
        # [Theory] Expert-relative threshold: δ = τ * S_E
        # S_E: ideal expert score under your raw reward definition
        # FM(expert)=1, GAIL(expert)=log 2 (when D=0.5 at equilibrium)
        # -------------------------
        self.S_E = cfg.w_fm * 1.0 + cfg.w_gail * math.log(2.0)
        self.confidence_level = cfg.confidence_level

        # -------------------------
        # [Theory] Trust-region increment: ρ = exp(κ/d) - 1
        # d: number of randomized scalar dimensions
        # -------------------------
        self.param_dim = self._count_uncertainty_dims(self.max_params)
        self.rho = math.exp(cfg.kappa / max(self.param_dim, 1)) - 1.0
        
        # Bayesian running stats over rollout-means y_t (Welford)
        self._n = 0
        self._mean = 0.0
        self._M2 = 0.0

        # optional for logging
        self.last_confidence = 0.0
        self.last_gate_mean = 0.0
        
        self.start_min_reward = 0.0
        self.end_max_reward = self.S_E
        self.target_score = self.start_min_reward + (self.end_max_reward - self.start_min_reward) * float(self.difficulty_level)
        
        self.gate_window = cfg.gate_window
        self._gate_buf = deque(maxlen=self.gate_window)
        
        # domain param buffer
        self._primary_asset_cfg: SceneEntityCfg | None = self._infer_primary_asset_cfg()
        self._current_domain: dict[str, torch.Tensor] = {}      # per-env snapshots
        self._current_domain_vec: torch.Tensor | None = None    # optional flattened vector per env
        self._init_domain_buffers()
        
        self._apply_curriculum()
        print(f"[DomainManager] Initialized. Curriculum Level: {self.difficulty_level}")
        print("[DomainManager] reset terms:", self._mode_term_names.get("reset", []))
        self._capture_current_domain(torch.arange(self.num_envs, device=self.device, dtype=torch.long))
        
        # episode logging
        self._episode_id = torch.zeros(self.num_envs, dtype=torch.long, device="cpu")  # per-env episode counter
        self._episode_records: list[dict[str, Any]] = [] 

    def _count_uncertainty_dims(self, max_params: dict) -> int:
        d = 0
        for _, term in (max_params or {}).items():
            if not isinstance(term, dict):
                continue
            for k, v in term.items():
                if k == "operation":
                    continue
                # (min, max) range -> 1 dimension
                if isinstance(v, (tuple, list)) and len(v) == 2 and isinstance(v[0], (int, float)):
                    d += 1
                # dict of axis ranges -> count per axis
                elif isinstance(v, dict):
                    for _, axis_range in v.items():
                        if isinstance(axis_range, (tuple, list)) and len(axis_range) == 2:
                            d += 1
                # single scalar max -> 1 dimension
                elif isinstance(v, (int, float)):
                    d += 1
        return max(d, 1)
        
    def _bayes_confidence_mu_gt_delta(self):
        n = len(self._gate_buf)
        if n < 2:
            mu = sum(self._gate_buf) / max(n, 1)
            return 0.0, float(mu)

        mu = sum(self._gate_buf) / n
        var = sum((v - mu) ** 2 for v in self._gate_buf) / (n - 1)   # unbiased
        s = math.sqrt(max(var, 1e-12))
        se = s / math.sqrt(n)

        t_score = (self.target_score - mu) / max(se, 1e-12)
        conf = float(1.0 - stats.t.cdf(float(t_score), df=n - 1))
        return conf, float(mu)
    
    def get_current_domain_params(
        self,
        env_ids: Sequence[int] | torch.Tensor | None = None,
        detach: bool = True,
        to_cpu: bool = False,
        as_vector: bool = False,
    ) -> dict[str, Any] | torch.Tensor:
        """Get the latest captured domain parameters for given env_ids.

        Returns:
            - dict[str, Tensor]: keys like 'mass', 'com', 'stiffness', 'damping', ...
            - or flattened Tensor (num_envs, D) if as_vector=True
        """
        if as_vector:
            if self._current_domain_vec is None:
                self._rebuild_domain_vector()
            out = self._current_domain_vec
            if env_ids is not None:
                env_ids_t = self._as_env_ids_tensor(env_ids)
                out = out[env_ids_t]
            if detach:
                out = out.detach()
            if to_cpu:
                out = out.cpu()
            return out

        # dict output
        result: dict[str, Any] = {}
        env_ids_t = None if env_ids is None else self._as_env_ids_tensor(env_ids)
        for k, v in self._current_domain.items():
            vv = v if env_ids_t is None else v[env_ids_t]
            if detach:
                vv = vv.detach()
            if to_cpu:
                vv = vv.cpu()
            result[k] = vv
        # include scalar curriculum info too (replicated per-env for convenience)
        result["difficulty_level"] = float(self.difficulty_level)
        return result

    def _record_episode_start(self, env_ids: torch.Tensor):
        """Record domain snapshot at episode start (right after reset randomization)."""
        dom = self.get_current_domain_params(env_ids=env_ids, detach=True, to_cpu=True, as_vector=False)

        # dom["difficulty_level"] is float, others are tensors on CPU now.
        # Build per-env records.
        env_ids_cpu = env_ids.detach().cpu().tolist()

        for local_i, eid in enumerate(env_ids_cpu):
            rec: dict[str, Any] = {
                "env_id": int(eid),
                "episode_id": int(self._episode_id[eid].item()),
                "difficulty_level": float(dom["difficulty_level"]),
            }
            for k, v in dom.items():
                if k == "difficulty_level":
                    continue
                if torch.is_tensor(v):
                    # v is (len(env_ids), Dk) for each key
                    rec[k] = v[local_i].clone()  # keep tensor (CPU) for exact reproducibility
                else:
                    rec[k] = v

            self._episode_records.append(rec)
            self._episode_id[eid] += 1

    def pop_episode_records(self) -> list[dict[str, Any]]:
        """Pop and clear episode records (so memory doesn't grow forever)."""
        out = self._episode_records
        self._episode_records = []
        return out

    # --------------------------------------------------------------------------------
    # NEW: Override apply() to capture domain snapshot after randomization events
    # --------------------------------------------------------------------------------
    def apply(self, mode: str, env_ids: Sequence[int] | torch.Tensor | None = None, **kwargs):
        """Apply domain randomization (event terms) and then capture the resulting physics parameters."""
        out = super().apply(mode=mode, env_ids=env_ids, **kwargs)

        # Capture after modes that actually change the domain.
        # (You can add 'interval' too if you randomize mid-episode.)
        if mode in ("startup", "reset", "prestartup"):
            env_ids_t = (
                torch.arange(self.num_envs, device=self.device, dtype=torch.long)
                if env_ids is None
                else self._as_env_ids_tensor(env_ids)
            )
            self._capture_current_domain(env_ids_t)
            self._record_episode_start(env_ids_t) 
        return out

    # --------------------------------------------------------------------------------
    # NEW: Internal helpers for domain capture
    # --------------------------------------------------------------------------------
    def _init_domain_buffers(self):
        """Initialize per-env storage tensors (empty until we can read actual values)."""
        # We'll store what we can read reliably from Articulation.data
        # Shape convention: (num_envs, dim)
        n = self.num_envs
        dev = self.device

        # Start with empty placeholders; we fill actual shapes after first read.
        self._current_domain = {}

        # Always keep a per-env scalar "domain_id" slot if you want later
        # (optional: for bucketing / replay)
        self._current_domain["domain_id"] = torch.full((n, 1), -1, device=dev, dtype=torch.int64)

        # Vector cache
        self._current_domain_vec = None

    def _as_env_ids_tensor(self, env_ids: Sequence[int] | torch.Tensor) -> torch.Tensor:
        """Convert env_ids to torch.LongTensor on correct device."""
        if isinstance(env_ids, torch.Tensor):
            return env_ids.to(device=self.device, dtype=torch.long)
        return torch.as_tensor(env_ids, device=self.device, dtype=torch.long)

    def _infer_primary_asset_cfg(self) -> SceneEntityCfg | None:
        """Try to infer which Articulation we should read parameters from (robot)."""
        candidate_keys = [
            "randomize_mass",
            "randomize_com",
            "randomize_gains",
            "randomize_joints",
            "randomize_friction",
            "randomize_base_mass",
        ]
        for key in candidate_keys:
            if not hasattr(self.cfg, key):
                continue
            term_cfg = getattr(self.cfg, key)
            if not isinstance(term_cfg, EventTermCfg):
                continue

            params = getattr(term_cfg, "params", {}) or {}
            # Common patterns in IsaacLab event randomization terms
            for pkey in ("asset_cfg", "asset", "robot_cfg", "entity_cfg"):
                if pkey in params and isinstance(params[pkey], SceneEntityCfg):
                    return params[pkey]

        return None
    
    def _capture_current_domain(self, env_ids: torch.Tensor):
        if self._primary_asset_cfg is None:
            return

        asset = self._env.scene[self._primary_asset_cfg.name]
        pv = asset.root_physx_view  # PhysX view (dof-level params live here)

        # ---------------- IDs (safe) ----------------
        if getattr(self._primary_asset_cfg, "body_names", None):
            body_ids = asset.find_bodies(self._primary_asset_cfg.body_names)[0]
        else:
            body_ids = slice(None)

        # NOTE: In IsaacLab, find_joints usually returns DOF indices for articulation.
        if getattr(self._primary_asset_cfg, "joint_names", None):
            dof_ids = asset.find_joints(self._primary_asset_cfg.joint_names)[0]
        else:
            dof_ids = slice(None)

        to_store: dict[str, torch.Tensor] = {}

        # ---------------- mass ----------------
        masses_all = pv.get_masses().to(self.device)  # (num_envs, num_bodies)
        masses = masses_all[env_ids][:, body_ids].clone()
        to_store["body_mass"] = masses

        # ---------------- com ----------------
        coms_all = pv.get_coms().to(self.device)      # (num_envs, num_bodies, 7) or (..., 3/7)
        com_pos = coms_all[env_ids][:, body_ids, :3].clone()
        to_store["body_com"] = com_pos.reshape(env_ids.numel(), -1)

        # =========================================================================
        # 1) DOF-level friction / gains  (this is the correct place to check first)
        # =========================================================================
        if hasattr(pv, "get_dof_friction_coefficients"):
            fr_all = pv.get_dof_friction_coefficients().to(self.device)  # (num_envs, num_dofs)
            fr = fr_all[env_ids][:, dof_ids].clone()
            to_store["dof_friction"] = fr

        if hasattr(pv, "get_dof_stiffnesses"):
            kp_all = pv.get_dof_stiffnesses().to(self.device)  # (num_envs, num_dofs)
            kp = kp_all[env_ids][:, dof_ids].clone()
            to_store["dof_stiffness"] = kp

        if hasattr(pv, "get_dof_dampings"):
            kd_all = pv.get_dof_dampings().to(self.device)  # (num_envs, num_dofs)
            kd = kd_all[env_ids][:, dof_ids].clone()
            to_store["dof_damping"] = kd

        # =========================================================================
        # 2) Actuator internal kp/kd (often the "real" gains if you use PD actuators)
        # =========================================================================
        def _pick_tensor(obj, keys):
            for k in keys:
                if hasattr(obj, k):
                    v = getattr(obj, k)
                    if isinstance(v, torch.Tensor):
                        return v
            return None

        act_kp_parts = []
        act_kd_parts = []
        if hasattr(asset, "actuators") and isinstance(asset.actuators, dict):
            for act_name, act in asset.actuators.items():
                # Different actuator implementations use different names
                kp_t = _pick_tensor(act, ["stiffness", "_stiffness", "kp", "_kp", "Kp"])
                kd_t = _pick_tensor(act, ["damping", "_damping", "kd", "_kd", "Kd"])

                # If tensors exist, store them (flatten per actuator)
                if kp_t is not None:
                    act_kp_parts.append(kp_t[env_ids].reshape(env_ids.numel(), -1).clone())
                if kd_t is not None:
                    act_kd_parts.append(kd_t[env_ids].reshape(env_ids.numel(), -1).clone())

        if len(act_kp_parts) > 0:
            to_store["act_kp"] = torch.cat(act_kp_parts, dim=1)
        if len(act_kd_parts) > 0:
            to_store["act_kd"] = torch.cat(act_kd_parts, dim=1)

        # (optional) DOF limits if you randomize joints/limits
        if hasattr(pv, "get_dof_limits"):
            lim_all = pv.get_dof_limits().to(self.device)  # (num_envs, num_dofs, 2)
            lim = lim_all[env_ids][:, dof_ids, :].clone()
            to_store["dof_limits"] = lim.reshape(env_ids.numel(), -1)

        # ---------------- write buffers (must be 2D) ----------------
        for k, v in to_store.items():
            if v.ndim == 1:
                v = v.view(-1, 1)
            self._current_domain[k] = self._update_rows(self._current_domain.get(k, None), env_ids, v)

        self._current_domain_vec = None

    def _update_rows(
        self,
        buf: torch.Tensor | None,
        env_ids: torch.Tensor,
        new_rows: torch.Tensor,
    ) -> torch.Tensor:
        """Create or update a (num_envs, D) buffer by writing rows at env_ids."""
        n = self.num_envs
        dev = self.device
        if buf is None:
            buf = torch.zeros((n, new_rows.shape[1]), device=dev, dtype=new_rows.dtype)
        # shape safety
        if buf.shape[1] != new_rows.shape[1]:
            buf = torch.zeros((n, new_rows.shape[1]), device=dev, dtype=new_rows.dtype)
        buf[env_ids] = new_rows
        return buf

    def _rebuild_domain_vector(self):
        """Flatten current domain dict into a single vector per env: (num_envs, D)."""
        parts = []
        # deterministic order
        for k in sorted(self._current_domain.keys()):
            v = self._current_domain[k]
            if v is None:
                continue
            # ensure 2D
            if v.ndim == 1:
                v = v.view(-1, 1)
            parts.append(v.to(dtype=torch.float32) if v.dtype != torch.float32 else v)
        if len(parts) == 0:
            self._current_domain_vec = torch.zeros((self.num_envs, 0), device=self.device, dtype=torch.float32)
        else:
            self._current_domain_vec = torch.cat(parts, dim=1)

    def _capture_max_params(self):
        target_terms = ["randomize_mass", "randomize_com", "randomize_gains", "randomize_joints", 
                        "randomize_friction", "randomize_base_mass"]
        
        for term_name in target_terms:
            if hasattr(self.cfg, term_name):
                term_cfg = getattr(self.cfg, term_name)
                # params 딕셔너리를 통째로 복사해서 저장 (Deep Copy 권장)
                if hasattr(term_cfg, "params"):
                    self.max_params[term_name] = term_cfg.params.copy()
                    print(f"[DomainManager] Stored max params for term: {term_name}, params: {self.max_params[term_name]}")

    def update_curriculum(self, mean_raw_reward: float):
        # 현재 difficulty 기준 gate 목표(δ) 업데이트
        self.target_score = self.start_min_reward + (self.end_max_reward - self.start_min_reward) * float(self.difficulty_level)

        y = float(mean_raw_reward)
        self._gate_buf.append(y)

        n = len(self._gate_buf)
        min_n = max(int(self.cfg.min_gate_samples), 2)
        if n < min_n:
            self.last_confidence = 0.0
            self.last_gate_mean = float(sum(self._gate_buf) / max(n, 1))
            return

        conf, mu = self._bayes_confidence_mu_gt_delta()
        self.last_confidence = conf
        self.last_gate_mean = mu

        print(f"conf: {conf:.4f} | mu: {mu:.4f} | target: {self.target_score:.4f} | n: {n}")
        for index, term_cfg in enumerate(self._mode_term_cfgs['reset']):
            print(term_cfg.params)

        if conf >= self.confidence_level and self.difficulty_level < 1.0:
            # trust-region step
            if self.difficulty_level <= 0.0:
                self.difficulty_level = min(1.0, max(1e-6, self.initial_level))
            else:
                self.difficulty_level = min(1.0, self.difficulty_level * (1.0 + self.rho))

            # 새 level에 맞춰 다음 regime의 target_score도 갱신
            self.target_score = self.start_min_reward + (self.end_max_reward - self.start_min_reward) * float(self.difficulty_level)
            self.target_score = min(self.end_max_reward, self.target_score)

            print(
                f"[DomainManager] 🆙 Expand | lvl={self.difficulty_level:.4f} "
                f"| gate_mean={mu:.4f} "
                f"| New target={self.target_score:.4f} "
                f"| conf={conf*100:.1f}% "
                f"| rho={self.rho:.6f} (d={self.param_dim})"
            )

            self._apply_curriculum()
            self._gate_buf.clear()

    def get_curriculum_info(self):
        return {
            "Difficulty_Level": float(self.difficulty_level),
            "Target_Score": float(self.target_score),
            "Gate_Mean": float(self.last_gate_mean),
            "Gate_Conf": float(self.last_confidence),
            "Rho": float(self.rho),
            "Dim_d": int(self.param_dim),
        }

    def _apply_curriculum(self):
        level = self.difficulty_level
        
        for term_name, max_p in self.max_params.items():
            if not hasattr(self.cfg, term_name): continue
            current_term_cfg = getattr(self.cfg, term_name)
            
            operation = max_p.get("operation", "add")

            base = 1.0 if operation == "scale" else 0.0
            
            # 3. 파라미터 보간
            for param_key, max_val in max_p.items():
                # (A )튜플/리스트 범위 (min, max)
                if isinstance(max_val, (tuple, list)) and len(max_val) == 2 and isinstance(max_val[0], (int, float)):
                    min_v, max_v = max_val
                    current_min = base + level * (min_v - base)
                    current_max = base + level * (max_v - base)
                    current_term_cfg.params[param_key] = (current_min, current_max)
                    
                # (B) 딕셔너리 범위 (CoM 등)
                elif isinstance(max_val, dict) and "range" in param_key:
                    new_range_dict = {}
                    for axis, axis_range in max_val.items():
                        if isinstance(axis_range, (tuple, list)) and len(axis_range) == 2:
                            a_min, a_max = axis_range
                            coord_base = 0.0 
                            cur_a_min = coord_base + level * (a_min - coord_base)
                            cur_a_max = coord_base + level * (a_max - coord_base)
                            new_range_dict[axis] = (cur_a_min, cur_a_max)
                    current_term_cfg.params[param_key] = new_range_dict

        self._update_internal_term_params()
        
        if hasattr(self.cfg, "randomize_mass"):
            mass_cfg = self.cfg.randomize_mass
            print("[DM] level =", level,
              "mass_dist =", mass_cfg.params.get("mass_distribution_params", None))
        if hasattr(self.cfg, "randomize_gains"):
            gains_cfg = self.cfg.randomize_gains
            print("[DM] stiffness_dist =", gains_cfg.params.get("stiffness_distribution_params", None),
                  "damping_dist =", gains_cfg.params.get("damping_distribution_params", None))

    def _update_internal_term_params(self):
        if "reset" in self._mode_term_cfgs:
            for i, term_cfg in enumerate(self._mode_term_cfgs["reset"]):
                # 해당 모드의 텀 이름 리스트에서 이름 가져오기
                if i < len(self._mode_term_names["reset"]):
                    term_name = self._mode_term_names["reset"][i]
                    
                    # cfg에 있는 최신 params로 덮어쓰기
                    if hasattr(self.cfg, term_name):
                        new_params = getattr(self.cfg, term_name).params
                        term_cfg.params.update(new_params)
                        
    def _prepare_terms(self):
        self._interval_term_time_left: list[torch.Tensor] = list()
        self._reset_term_last_triggered_step_id: list[torch.Tensor] = list()
        self._reset_term_last_triggered_once: list[torch.Tensor] = list()

        if isinstance(self.cfg, dict):
            cfg_items = self.cfg.items()
        else:
            cfg_items = self.cfg.__dict__.items()
            
        # iterate over all the terms
        for term_name, term_cfg in cfg_items:
            if term_cfg is None: continue
            
            if not isinstance(term_cfg, EventTermCfg):
                continue
            
            self._resolve_common_term_cfg(term_name, term_cfg, min_argc=2)

            if term_cfg.mode == "prestartup" and self._env.scene.cfg.replicate_physics:
                raise RuntimeError("Scene replication enabled, cannot use prestartup events.")

            if inspect.isclass(term_cfg.func) and term_cfg.mode == "prestartup":
                term_cfg.func = term_cfg.func(cfg=term_cfg, env=self._env)

            if term_cfg.mode not in self._mode_term_names:
                self._mode_term_names[term_cfg.mode] = list()
                self._mode_term_cfgs[term_cfg.mode] = list()
                self._mode_class_term_cfgs[term_cfg.mode] = list()
            
            self._mode_term_names[term_cfg.mode].append(term_name)
            self._mode_term_cfgs[term_cfg.mode].append(term_cfg)

            if inspect.isclass(term_cfg.func):
                self._mode_class_term_cfgs[term_cfg.mode].append(term_cfg)

            if term_cfg.mode == "interval":
                if term_cfg.interval_range_s is None:
                    raise ValueError(f"Event term '{term_name}' mode 'interval' requires 'interval_range_s'.")
                if term_cfg.is_global_time:
                    lower, upper = term_cfg.interval_range_s
                    time_left = torch.rand(1) * (upper - lower) + lower
                    self._interval_term_time_left.append(time_left)
                else:
                    lower, upper = term_cfg.interval_range_s
                    time_left = torch.rand(self.num_envs, device=self.device) * (upper - lower) + lower
                    self._interval_term_time_left.append(time_left)
            elif term_cfg.mode == "reset":
                if term_cfg.min_step_count_between_reset < 0:
                    raise ValueError(f"Negative min_step_count for term '{term_name}'.")
                step_count = torch.zeros(self.num_envs, device=self.device, dtype=torch.int32)
                self._reset_term_last_triggered_step_id.append(step_count)
                no_trigger = torch.zeros(self.num_envs, device=self.device, dtype=torch.bool)
                self._reset_term_last_triggered_once.append(no_trigger)