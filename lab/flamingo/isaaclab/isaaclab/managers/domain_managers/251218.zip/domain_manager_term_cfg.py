# domain_manager_term_cfg.py

from __future__ import annotations
from dataclasses import field
from isaaclab.utils import configclass
from isaaclab.managers.event_manager import EventTermCfg


@configclass
class DomainManagerTermCfg:
    # ---------------------------------------------------------------------
    # Curriculum (old gate: discriminator prob)
    # ---------------------------------------------------------------------
    init_difficulty_level: float = 0.0
    curriculum_threshold: float = 0.2
    curriculum_threshold_increment: float = 0.005
    curriculum_stage_gain: float = 0.05

    tau: float = 0.8
    kappa: float = 0.1
    confidence_level: float = 0.95
    w_fm: float = 0.8
    w_gail: float = 0.2
    initial_level: float = 0.05
    
    # heurisitc find,,,
    start_min_reward : float = 0.05
    end_max_reward : float =0.15
    
    min_gate_samples : int = 20
    gate_window : int = 100